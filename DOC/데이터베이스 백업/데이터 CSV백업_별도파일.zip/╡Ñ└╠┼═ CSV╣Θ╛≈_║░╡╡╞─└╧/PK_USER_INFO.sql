--------------------------------------------------------
--  DDL for Index PK_USER_INFO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_USER_INFO" ON "USER_INFO" ("USER_ID") 
  ;
