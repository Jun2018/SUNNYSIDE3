--------------------------------------------------------
--  DDL for Sequence MAIN_IMG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "MAIN_IMG_SEQ"  MINVALUE 1 MAXVALUE 100000 INCREMENT BY 1 START WITH 81 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
