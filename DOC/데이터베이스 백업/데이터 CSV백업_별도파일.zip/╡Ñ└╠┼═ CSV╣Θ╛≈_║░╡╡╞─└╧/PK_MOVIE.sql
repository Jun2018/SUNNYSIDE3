--------------------------------------------------------
--  DDL for Index PK_MOVIE
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_MOVIE" ON "MOVIE" ("MOVIE_ID") 
  ;
