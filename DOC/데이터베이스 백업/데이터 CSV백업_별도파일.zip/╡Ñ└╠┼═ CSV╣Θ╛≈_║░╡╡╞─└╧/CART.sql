--------------------------------------------------------
--  DDL for Table CART
--------------------------------------------------------

  CREATE TABLE "CART" 
   (	"CART_ID" VARCHAR2(20 BYTE), 
	"USER_ID" VARCHAR2(20 BYTE), 
	"COUNT" NUMBER(4,0), 
	"PRODUCT_ID" VARCHAR2(20 BYTE), 
	"PAY_CODE" VARCHAR2(20 BYTE)
   ) ;

   COMMENT ON COLUMN "CART"."CART_ID" IS '장바구니코드';
   COMMENT ON COLUMN "CART"."USER_ID" IS '회원ID';
   COMMENT ON COLUMN "CART"."COUNT" IS '수량';
   COMMENT ON COLUMN "CART"."PRODUCT_ID" IS '상품ID';
   COMMENT ON COLUMN "CART"."PAY_CODE" IS '상품 결제코드';
   COMMENT ON TABLE "CART"  IS '장바구니';
