--------------------------------------------------------
--  DDL for Index PK_CODE
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CODE" ON "CODE" ("CODE_TYPE_ID", "CODE_ID") 
  ;
