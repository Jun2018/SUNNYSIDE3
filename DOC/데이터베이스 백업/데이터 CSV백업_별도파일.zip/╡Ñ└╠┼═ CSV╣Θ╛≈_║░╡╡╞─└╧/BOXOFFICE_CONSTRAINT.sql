--------------------------------------------------------
--  Constraints for Table BOXOFFICE
--------------------------------------------------------

  ALTER TABLE "BOXOFFICE" MODIFY ("MOVIE_ID" NOT NULL ENABLE);
  ALTER TABLE "BOXOFFICE" ADD CONSTRAINT "PK_BOXOFFICE" PRIMARY KEY ("MOVIE_ID")
  USING INDEX  ENABLE;
