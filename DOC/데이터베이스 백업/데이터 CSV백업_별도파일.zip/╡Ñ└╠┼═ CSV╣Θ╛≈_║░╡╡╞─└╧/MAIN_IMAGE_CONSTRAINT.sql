--------------------------------------------------------
--  Constraints for Table MAIN_IMAGE
--------------------------------------------------------

  ALTER TABLE "MAIN_IMAGE" MODIFY ("IMAGE_ID" NOT NULL ENABLE);
  ALTER TABLE "MAIN_IMAGE" ADD CONSTRAINT "PK_MAIN_IMAGE" PRIMARY KEY ("IMAGE_ID")
  USING INDEX  ENABLE;
