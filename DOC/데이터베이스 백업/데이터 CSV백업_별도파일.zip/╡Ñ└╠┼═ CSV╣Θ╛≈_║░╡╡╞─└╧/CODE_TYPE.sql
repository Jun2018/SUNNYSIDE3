--------------------------------------------------------
--  DDL for Table CODE_TYPE
--------------------------------------------------------

  CREATE TABLE "CODE_TYPE" 
   (	"CODE_TYPE_ID" VARCHAR2(30 BYTE), 
	"CODE_TYPE_NM" VARCHAR2(100 BYTE)
   ) ;

   COMMENT ON COLUMN "CODE_TYPE"."CODE_TYPE_ID" IS '코드유형ID';
   COMMENT ON COLUMN "CODE_TYPE"."CODE_TYPE_NM" IS '코드유형명';
   COMMENT ON TABLE "CODE_TYPE"  IS '공통코드유형';
