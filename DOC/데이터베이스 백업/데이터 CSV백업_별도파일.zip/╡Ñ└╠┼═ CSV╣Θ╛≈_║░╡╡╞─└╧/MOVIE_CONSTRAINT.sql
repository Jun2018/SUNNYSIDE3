--------------------------------------------------------
--  Constraints for Table MOVIE
--------------------------------------------------------

  ALTER TABLE "MOVIE" MODIFY ("MOVIE_ID" NOT NULL ENABLE);
  ALTER TABLE "MOVIE" ADD CONSTRAINT "PK_MOVIE" PRIMARY KEY ("MOVIE_ID")
  USING INDEX  ENABLE;
