--------------------------------------------------------
--  Constraints for Table NOTICE
--------------------------------------------------------

  ALTER TABLE "NOTICE" MODIFY ("NOTICE_ID" NOT NULL ENABLE);
  ALTER TABLE "NOTICE" ADD CONSTRAINT "NOTICE_PK" PRIMARY KEY ("NOTICE_ID")
  USING INDEX (CREATE UNIQUE INDEX "PK_NOTICE" ON "NOTICE" ("NOTICE_ID") 
  )  ENABLE;
