--------------------------------------------------------
--  Constraints for Table TICKET_HISTORY
--------------------------------------------------------

  ALTER TABLE "TICKET_HISTORY" MODIFY ("TICKET_CODE" NOT NULL ENABLE);
  ALTER TABLE "TICKET_HISTORY" ADD CONSTRAINT "PK_TICKET_HISTORY" PRIMARY KEY ("TICKET_CODE")
  USING INDEX  ENABLE;
