--------------------------------------------------------
--  DDL for Table TEST
--------------------------------------------------------

  CREATE TABLE "TEST" 
   (	"NAME" VARCHAR2(20 BYTE), 
	"ADREES" VARCHAR2(20 BYTE)
   ) ;
