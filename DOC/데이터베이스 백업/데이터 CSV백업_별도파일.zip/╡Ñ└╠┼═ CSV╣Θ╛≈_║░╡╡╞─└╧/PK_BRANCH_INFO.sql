--------------------------------------------------------
--  DDL for Index PK_BRANCH_INFO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_BRANCH_INFO" ON "BRANCH_INFO" ("BRANCH_ID") 
  ;
