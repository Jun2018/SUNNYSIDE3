--------------------------------------------------------
--  DDL for Table MAIN_IMAGE
--------------------------------------------------------

  CREATE TABLE "MAIN_IMAGE" 
   (	"IMAGE_ID" VARCHAR2(20 BYTE), 
	"ORG_IMG_NM" VARCHAR2(100 CHAR), 
	"SAVE_IMG_NM" VARCHAR2(100 CHAR), 
	"EXT" VARCHAR2(4 BYTE), 
	"IMG_SIZE" NUMBER(10,2), 
	"REG_DT" DATE
   ) ;

   COMMENT ON COLUMN "MAIN_IMAGE"."IMAGE_ID" IS '이미지ID';
   COMMENT ON COLUMN "MAIN_IMAGE"."ORG_IMG_NM" IS '원본사진명';
   COMMENT ON COLUMN "MAIN_IMAGE"."SAVE_IMG_NM" IS '저장사진명';
   COMMENT ON COLUMN "MAIN_IMAGE"."EXT" IS '확장자명';
   COMMENT ON COLUMN "MAIN_IMAGE"."IMG_SIZE" IS '용량';
   COMMENT ON COLUMN "MAIN_IMAGE"."REG_DT" IS '등록일';
   COMMENT ON TABLE "MAIN_IMAGE"  IS '메인이미지';
