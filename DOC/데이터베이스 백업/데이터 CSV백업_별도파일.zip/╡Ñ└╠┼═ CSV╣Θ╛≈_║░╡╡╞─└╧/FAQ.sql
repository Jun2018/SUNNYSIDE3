--------------------------------------------------------
--  DDL for Table FAQ
--------------------------------------------------------

  CREATE TABLE "FAQ" 
   (	"QUESTION_ID" VARCHAR2(20 BYTE), 
	"TITLE" VARCHAR2(200 BYTE), 
	"CONTENTS" VARCHAR2(200 BYTE), 
	"REG_DT" DATE
   ) ;

   COMMENT ON COLUMN "FAQ"."QUESTION_ID" IS '질문ID';
   COMMENT ON COLUMN "FAQ"."TITLE" IS '제목';
   COMMENT ON COLUMN "FAQ"."CONTENTS" IS '내용';
   COMMENT ON COLUMN "FAQ"."REG_DT" IS '등록일';
   COMMENT ON TABLE "FAQ"  IS '자주하는질문';
