--------------------------------------------------------
--  DDL for Index PK_USER_COUPON
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_USER_COUPON" ON "USER_COUPON" ("COUPON_CODE") 
  ;
