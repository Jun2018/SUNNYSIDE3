--------------------------------------------------------
--  DDL for Index PK_BOXOFFICE
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_BOXOFFICE" ON "BOXOFFICE" ("MOVIE_ID") 
  ;
