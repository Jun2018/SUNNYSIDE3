--------------------------------------------------------
--  Ref Constraints for Table ROOM
--------------------------------------------------------

  ALTER TABLE "ROOM" ADD CONSTRAINT "FK_BRANCH_INFO_TO_ROOM" FOREIGN KEY ("BRANCH_ID")
	  REFERENCES "BRANCH_INFO" ("BRANCH_ID") ENABLE;
