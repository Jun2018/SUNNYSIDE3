--------------------------------------------------------
--  DDL for Index PK_SCREEN_INFO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_SCREEN_INFO" ON "SCREEN_INFO" ("SCREEN_ID") 
  ;
