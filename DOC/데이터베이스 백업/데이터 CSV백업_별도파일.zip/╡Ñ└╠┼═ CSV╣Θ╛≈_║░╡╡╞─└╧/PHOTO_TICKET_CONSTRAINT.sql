--------------------------------------------------------
--  Constraints for Table PHOTO_TICKET
--------------------------------------------------------

  ALTER TABLE "PHOTO_TICKET" MODIFY ("TICKET_CODE" NOT NULL ENABLE);
  ALTER TABLE "PHOTO_TICKET" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "PHOTO_TICKET" ADD CONSTRAINT "PK_PHOTO_TICKET" PRIMARY KEY ("TICKET_CODE")
  USING INDEX  ENABLE;
