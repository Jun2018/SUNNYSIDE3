--------------------------------------------------------
--  DDL for Table BRANCH_INFO
--------------------------------------------------------

  CREATE TABLE "BRANCH_INFO" 
   (	"BRANCH_ID" VARCHAR2(20 BYTE), 
	"BRANCH_NM" VARCHAR2(20 CHAR)
   ) ;

   COMMENT ON COLUMN "BRANCH_INFO"."BRANCH_ID" IS '지점ID';
   COMMENT ON COLUMN "BRANCH_INFO"."BRANCH_NM" IS '지점명';
   COMMENT ON TABLE "BRANCH_INFO"  IS '지점정보';
