--------------------------------------------------------
--  DDL for Index PK_TICKET_HISTORY
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_TICKET_HISTORY" ON "TICKET_HISTORY" ("TICKET_CODE") 
  ;
